# _*_ coding:utf-8 _*_

import unittest
import requests
import ddt
from lib.read_excel import ReadExcel
from call_api import CallAPI
from lib.parse_file import generate_file_path

# 读取测试用例
case_file = generate_file_path(".DemoAPITestCase_Flow.xlsx", flag='c')
testData = ReadExcel(case_file, "Sheet1").read_data()
# excel版测试报告，同时用于存储每个接口的返回结果
report_file = generate_file_path(".DemoAPITestCase_Flow.xlsx", flag='r')


# 脚本均继承CallAPI类，复用call_api方法
@ddt.ddt
class FlowDemoAPI(unittest.TestCase, CallAPI):
    """XXX系统"""
    def setUp(self):
        self.s = requests.session()

    def tearDown(self):
        pass

    # 数据驱动测试，excel中每一行视为一条测试用例传给方法的data参数
    @ddt.data(*testData)
    def test_flow_api(self, data):
        """
        数据驱动从第1个接口往下执行，因此通过if判断当前正在执行的接口
        执行后续依赖接口，可能会用到之前接口的返回数据如token或者从数据库拿数据，则可以在每个接口调用前重构data参数
        """
        if data['ID'] == 'login_trigger_001':
            self.call_api(data)
        if data['ID'] == 'project_load_002':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            tempData = ReadExcel(report_file, "Sheet1").read_data()
            pre_api_response = [item for item in tempData if item['ID'] == 'login_trigger_001']
            authorization = "Bearer " + eval(pre_api_response[0]['response'])['access_token']
            headers = eval(data['headers'])
            headers['Authorization'] = authorization
            data['headers'] = str(headers)

            # 调用API请求函数
            self.call_api(data)


if __name__ == '__main__':
    unittest.main()
