# _*_ coding:utf-8 _*_

import unittest
import requests
import ddt
from config.setting import ENV
from lib.read_excel import ReadExcel
from lib.parse_file import generate_file_path
from lib.project_functions import parse_token, rebuild_header, fetch_project_base_url
from lib.parse_file import ParseCSV
from lib.log import logger
from lib.project_functions import rebuild_login_body, rebuild_url
from testcase.call_api import CallAPI

case_file = generate_file_path("dc_home_and_createProject_API_TestCase.xlsx", flag='c')
report_file = generate_file_path("dc_home_and_createProject_API_TestCase.xlsx", flag='r')
testData = ReadExcel(case_file, "Sheet1").read_data()

access_token = ""
DC_BASE_URL = fetch_project_base_url(ENV)


@ddt.ddt
class HomeAndCreateProjectAPI(unittest.TestCase, CallAPI):
    """EDMS_DC_测试用户登陆系统后，主页请求的接口及导航至创建项目页所请求的接口"""
    def setUp(self):
        self.s = requests.session()
        # 获取用户信息
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.account = accounts[1][1]
            self.password = accounts[1][2]
            self.staff_no = accounts[1][3]
            self.en_name = accounts[1][5]
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        # 获取用例与excel报告文件地址
        self.case_file = case_file
        self.report_file = report_file

    def tearDown(self):
        pass

    @ddt.data(*testData)
    def test_home_and_create_project_apis(self, data):
        """
        测试用户登陆系统后，主页请求的接口
        """
        global access_token

        if data['ID'] == 'login_trigger_001':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.account)
            self.call_api(data)
        if data['ID'] == 'home_loadMenu_002':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_trigger_001')
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'home_loadUserInfo_003':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'home_loadUserRoles_004':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'home_loadEnvLinks_005':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'home_calPendingCount_006':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_loadProject_007':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_loadProjectRole_008':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_archiveDuration_009':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_serviceLine_010':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_staffLevel_011':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_projectType_012':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_serviceOffering_013':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_engRisk_014':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_guidePrompt_015':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'projectMgt_formSetting_016':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)


if __name__ == '__main__':
    unittest.main()
