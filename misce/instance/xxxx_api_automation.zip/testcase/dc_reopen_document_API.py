# _*_ coding:utf-8 _*_

import unittest, requests, ddt, re, json, uuid
from lib.read_excel import ReadExcel
from config.setting import ENV, PROJECT_PATH
from call_api import CallAPI
from lib.parse_file import generate_file_path
from lib.project_functions import rebuild_header, fetch_user_info, parse_token,\
    replace_project_user, replace_project_name, replace_client_name, replace_body_item, rebuild_url,\
    rebuild_login_body, fetch_project_base_url, fetch_db_config, replace_params_item
from lib.parse_file import ParseCSV
from lib.log import logger
from lib.timer import FormatTime
from lib.mssql_db import MSSQL
from lib.trigger_job import trigger_job
import configparser as cparser
from config import setting

# --------- 读取config.ini配置文件 ---------------
cf = cparser.ConfigParser()
cf.read(setting.TEST_CONFIG, encoding='UTF-8')
host, port, user, pwd, db = fetch_db_config(cf, ENV)
# toolkit申请JSON字符数太长，单独维护在下面文件中
apply_file = 'DC_toolkit_apply_template.txt'
km_approve_file = 'DC_toolkit_km_approve_template.txt'
pic_approve_file = 'DC_toolkit_pic_approve_template.txt'

case_file = generate_file_path("dc_reopen_document_API_TestCase.xlsx", flag='c')
report_file = generate_file_path("dc_reopen_document_API_TestCase.xlsx", flag='r')
testData = ReadExcel(case_file, "Sheet1").read_data()

DC_BASE_URL = fetch_project_base_url(ENV)
access_token = ""
project_name_with_code = ""
client_name = ""
project_id = ""
survey1_id = ""
survey2_id = ""
survey3_id = ""
courser = ""
request_no = ""
request_id = ""
stage_id = ""


@ddt.ddt
class ReopenDocumentAPI(unittest.TestCase, CallAPI):
    """EDMS_DC_测试提交文件操作类项目重启申请，然后审核全流程"""
    def setUp(self):
        self.s = requests.session()
        # 获取用户信息
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.account = accounts[2][1]
            self.password = accounts[2][2]
            self.staff_no = accounts[2][3]
            self.en_name = accounts[2][5]
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        # 获取用例与excel报告文件地址
        self.case_file = case_file
        self.report_file = report_file

    def tearDown(self):
        pass

    @ddt.data(*testData)
    def test_reopen_document_apis(self, data):
        """
        测试用户创建项目并提交toolkit申请，然后审核全流程
        """
        global access_token, project_name_with_code, project_id, courser, request_no, request_id, client_name, stage_id
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.staff = fetch_user_info(accounts, 'staff')
            self.mic = fetch_user_info(accounts, 'mic')
            self.pic = fetch_user_info(accounts, 'pic')
            self.cpic = fetch_user_info(accounts, 'cpic')
            self.special_risk = fetch_user_info(accounts, 'specialRisk')
            self.ppic = fetch_user_info(accounts, 'ppic')
            self.kit_review = fetch_user_info(accounts, 'kitReview')
            self.opl = fetch_user_info(accounts, 'offeringPortfolio')
            self.reopen = fetch_user_info(accounts, 'reopen')
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        if data['ID'] == 'login_trigger_001':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.account)
            self.call_api(data)
        if data['ID'] == 'project_createWithEngCode_002':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_trigger_001')
            data['headers'] = rebuild_header(data['headers'], access_token)
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            # 向dms_sync_project表插入一条项目数据用于创建有CODE项目
            current_time = str(FormatTime(shift_minute=15).formater_4())
            sync_code_sql = "INSERT INTO [dms_sync_project]([id], [creation_date], [created_by], [created_by_en_name], [created_by_name], [del_flag], [deleted_by], [deletion_date], [last_updated_by], [last_updated_by_enname], [last_updated_by_name], [last_update_date], [status], [tenant_id], [record_version], [affiliate_of_listed_entity], [affiliate_of_sec_restricted_entity], [biz_registration_no], [cea_approval_date], [cea_ecc_case_no], [cea_no], [cea_preparer], [cea_status], [chinese_name1], [chinese_name2], [client_code], [client_name], [client_risk], [close_date], [engagement_code], [company_code], [con_curring_partner_reason], [con_partner_advise_engagement], [confidentiality_risk], [contract_c], [dtt_relation_ship], [eng_code], [eng_desc], [eng_letter_no], [engagement_desc], [engagement_risk], [eqar_partner], [est_fee], [existing_audit_client], [fisy], [func_code], [industry_code], [industry_desc], [is_contingent_basis], [is_master_eng], [is_recurring], [lcsp], [lcsp_name], [legal_name], [location_code], [master_eng_code], [mic], [mic_name], [nature_of_business], [opportunity_id], [opportunity_name], [opportunity_source], [pic], [pic_name], [plan_recover_rate], [primary_addr], [primary_city], [primary_country], [primary_province], [profit_center], [rc_code], [region_code], [scope_of_services], [sec_registrant], [sec_restricted_entity], [segment_code], [service_code], [service_item_team_member], [service_offer_desc], [start_date], [stock_code], [stock_exchange], [type_of_client], [year_end_month], [master_company_cn], [master_code], [master_company], [ppic1], [ppic1_name], [ppic2], [ppic2name], [level1_code], [level2_code], [create_date], [segment_desc], [service_item_team_member_name], [cea_preparer_name], [eqar_partner_name], [ppic2_name], [ppic], [ppic_name], [alliance_partner], [alliance_partner_desc]) VALUES ('" + str(
                uuid.uuid1()) + "','2022-02-15 13:49:44.7280000', 'System', NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, '2022-02-15 13:49:44.7280000', NULL, 'DC', 1, 'No', 'Yes', '8080-01', '2020-01-05 09:44:00.0000000', 'CEA-SH-DC-456933', N'CEA-SH-DC-456933', '', 'Approved', N'Massive Data', N'HuaLongWang-MassiveData', N'8080', N'HuaLongWang-MassiveData HLW CO. LTD', 'High', NULL, N'" + current_time + "-02-DC',  N'SH3A', N'AutoTest for DC', 'No', 'Normal', N'USD', N'DTT_RelationShip', N'" + current_time + "-02-DC', N'AutoTest-20220215-134724', 'EL19SHF456933', N'AutoTest-20220215-134724', 'Much Great', '1004', 50000.00, 'Yes', 2021, N'CON', N'CTS2', N'Consumer/TH&S/Services', 'Yes', N'Y', N'N', N'1009', 'edmspicSM', N'CQ Press', N'SH', N'', N'1002', 'edmspicMic', N'Consumer/TH&S/Services', '456933', N'project-456933', N'Existing Client', N'1003', 'edmspicPic', 40.000000000000000, N'CQ Danzishi Energy Tower       ', N'China', N'Chongqing', N'Chongqing', N'16F140', '1FC1003069', N'EC', N'scope of service 456933', N'456933 & Co. Inc.', 'No', N'SOEZZZ0', N'OJC', N'1001', N'SAM JP-CN Collaboration', '2021-06-05 00:00:00.0000000', N'Stock_Code_Exchange;', N'', 'Corporation', N'10', N'德勤咨询（上海）有限公司', 'SH3A', 'Deloitte & ToucheFinancial Advisory Services Limited', N'10014', 'edmsmicPpic', N'', NULL, N'CZZ0', N'CTZ0', '2021-04-30 00:00:00.000', N'CENTRAL SOE', N'edmspicStaff', N'', N'edmspicCpic', N'', N'10014', N'edmsmicPpic', NULL, NULL);"
            courser.exec_non_query(sync_code_sql)
            # 查询项目CODE属性，用于填充创建项目接口参数
            eng_code_sql = "select top 1 master_company, company_code, engagement_code, client_code, client_name, cea_no, eng_letter_no, region_code, location_code, rc_code, master_company_cn from dms_sync_project where engagement_code like '" + current_time +"%' and engagement_code not in (select code from dms_project where code like '" + current_time +"%');"
            eng_code = courser.exec_query(eng_code_sql)[0]
            # 替换模板数据中项目人员数据
            data['body'] = replace_project_user(data['body'], self.staff, 'staff')
            data['body'] = replace_project_user(data['body'], self.mic, 'mic')
            data['body'] = replace_project_user(data['body'], self.pic, 'pic')
            data['body'] = replace_project_user(data['body'], self.cpic, 'cpic')
            data['body'] = replace_project_user(data['body'], self.special_risk, 'specialRisk')
            # 替换模板数据中CODE人员数据
            data['body'] = replace_project_user(data['body'], self.ppic, 'ppic')
            data['body'] = replace_project_user(data['body'], self.mic, 'codeMic')
            data['body'] = replace_project_user(data['body'], self.pic, 'codePic')
            # 修改模板数据中的非账号数据
            data['body'] = replace_body_item(data['body'], 'masterCompany', eng_code[0])
            data['body'] = replace_body_item(data['body'], 'masterCompanyCode', eng_code[1])
            data['body'] = replace_body_item(data['body'], 'code', eng_code[2])
            project_name_with_code = "DC_AutoTest_" + str(eng_code[2])
            data['body'] = replace_project_name(data['body'], project_name_with_code)
            data['body'] = replace_body_item(data['body'], 'clientCode', eng_code[3])
            data['body'] = replace_client_name(data['body'], eng_code[4])
            data['body'] = replace_body_item(data['body'], 'ceaNo', eng_code[5])
            data['body'] = replace_body_item(data['body'], 'engLetterNo', eng_code[6])
            data['body'] = replace_body_item(data['body'], 'regionCode', eng_code[7])
            data['body'] = replace_body_item(data['body'], 'locationCode', eng_code[8])
            data['body'] = replace_body_item(data['body'], 'rcCode', eng_code[9])
            data['body'] = replace_body_item(data['body'], 'masterCompanyCN', eng_code[10])
            data['body'] = replace_body_item(data['body'], 'engagementDesc', project_name_with_code + '_Desc')
            # 调用API请求函数
            self.call_api(data)
            # 调三方系统（任务调度中心）生成问卷
            survey = {"method": "POST",
                          "url": "/edms-pre-job/jobinfo/trigger",
                          "params": "",
                          "headers": {},
                          "body": {"id": "",
                                   "executorParam": "DC"},
                          "type": "data"}
            trigger_job(survey, ENV)
        if data['ID'] == 'project_fillSurvey1_003':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            project_sql = "SELECT id from dms_project where project_name='" + project_name_with_code + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            project_id = courser.exec_query(project_sql)[0][0]
            survey1_sql = "select id from dms_project_survey where code='Catalog1/3' and project_id='" + project_id + "';"
            survey1_id = courser.exec_query(survey1_sql)[0][0]
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], 'surveyId', survey1_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'project_fillSurvey2_004':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            survey2_sql = "select id from dms_project_survey where code='Catalog2/3' and project_id='" + project_id + "';"
            survey2_id = courser.exec_query(survey2_sql)[0][0]
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], 'surveyId', survey2_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'project_fillSurvey3_005':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            survey3_sql = "select id from dms_project_survey where code='Catalog3/3' and project_id='" + project_id + "';"
            survey3_id = courser.exec_query(survey3_sql)[0][0]
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], 'surveyId', survey3_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'toolkit_reviewerFind_006':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], 'projectId', project_id)
            stage_id_sql = "select id from dms_project_stage where project_id='" + project_id + "';"
            stage_id = courser.exec_query(stage_id_sql)[0][0]
            data['params'] = replace_params_item(data['params'], 'stageId', stage_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'toolkit_applySubmit_007':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)

            # 获取数据动态替换模板
            stage_id_sql = "select id from dms_project_stage where project_id='" + project_id + "';"
            stage_id = courser.exec_query(stage_id_sql)[0][0]
            json_template = PROJECT_PATH + u'/data/' + apply_file

            fp = open(json_template, 'r', encoding='UTF-8')
            data['body'] = fp.read()
            data['body'] = json.loads(data['body'])
            # 替换JSON模板中的projectId和stageId
            project_id_str = "'projectId': '" + project_id + "'"
            stage_id_str = "'stageId': '" + stage_id + "'"
            data['body'] = re.sub(r"'projectId': 'c1926d06-c103-43b6-9b5e-00d1290d9ac9'", project_id_str, str(data['body']))
            data['body'] = re.sub(r"'stageId': 'f8e04eda-5364-409e-988f-c944db4923e8'", stage_id_str, data['body'])
            # 替换一条特殊的stageId，在接口中命名为了ID
            data['body'] = eval(data['body'])
            data['body']['stageDetailForSaveVO']['id'] = stage_id
            data['body'] = json.dumps(data['body'], ensure_ascii=False)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'KM_login_008':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.kit_review[2])
            self.call_api(data)
        if data['ID'] == 'KM_approve_009':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'KM_login_008')
            data['headers'] = rebuild_header(data['headers'], access_token)

            # 获取数据动态替换模板
            pro_ins_sql = "select pro_ins_id from dms_project_stage where project_id='" + project_id + "';"
            pro_ins_id = courser.exec_query(pro_ins_sql)[0][0]
            km_template = PROJECT_PATH + u'/data/' + km_approve_file
            fp = open(km_template, 'r', encoding='UTF-8')
            data['body'] = fp.read()
            data['body'] = json.loads(data['body'])
            # 替换JSON模板中的projectId和stageId
            project_id_str = "'projectId': '" + project_id + "'"
            stage_id_str = "'stageId': '" + stage_id + "'"
            data['body'] = re.sub(r"'projectId': 'c1926d06-c103-43b6-9b5e-00d1290d9ac9'", project_id_str, str(data['body']))
            data['body'] = re.sub(r"'stageId': 'f8e04eda-5364-409e-988f-c944db4923e8'", stage_id_str, data['body'])
            # 替换一条特殊的stageId，在接口中命名为了ID
            data['body'] = eval(data['body'])
            data['body']['stageDetailForSaveVO']['id'] = stage_id
            # 手动替换pro_ins_id
            data['body']['stageDetailForSaveVO']['proInsId'] = pro_ins_id
            data['body'] = json.dumps(data['body'], ensure_ascii=False)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'PIC_login_010':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.pic[2])
            self.call_api(data)
        if data['ID'] == 'PIC_approve_011':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'PIC_login_010')
            data['headers'] = rebuild_header(data['headers'], access_token)

            # 获取数据动态替换模板
            pro_ins_sql = "select pro_ins_id from dms_project_stage where project_id='" + project_id + "';"
            pro_ins_id = courser.exec_query(pro_ins_sql)[0][0]
            pic_template = PROJECT_PATH + u'/data/' + pic_approve_file
            fp = open(pic_template, 'r', encoding='UTF-8')
            data['body'] = fp.read()
            data['body'] = json.loads(data['body'])
            # 替换JSON模板中的projectId和stageId
            project_id_str = "'projectId': '" + project_id + "'"
            stage_id_str = "'stageId': '" + stage_id + "'"
            data['body'] = re.sub(r"'projectId': 'c1926d06-c103-43b6-9b5e-00d1290d9ac9'", project_id_str, str(data['body']))
            data['body'] = re.sub(r"'stageId': 'f8e04eda-5364-409e-988f-c944db4923e8'", stage_id_str, data['body'])
            # 替换一条特殊的stageId，在接口中命名为了ID
            data['body'] = eval(data['body'])
            data['body']['stageDetailForSaveVO']['id'] = stage_id
            # 手动替换pro_ins_id
            data['body']['stageDetailForSaveVO']['proInsId'] = pro_ins_id
            data['body'] = json.dumps(data['body'], ensure_ascii=False)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'MIC_login_012':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.mic[2])
            self.call_api(data)
        if data['ID'] == 'Team_applyStatusLoad_013':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'MIC_login_012')
            data['headers'] = rebuild_header(data['headers'], access_token)
            self.call_api(data)
        if data['ID'] == 'Team_loadProjectRole_014':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            self.call_api(data)
        if data['ID'] == 'Team_getFileRoleFunctionList_015':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            self.call_api(data)
        if data['ID'] == 'Team_queryProject_016':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            self.call_api(data)
        if data['ID'] == 'Team_selectProject_017':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectId", project_id)
            self.call_api(data)
        if data['ID'] == 'Team_queryNextReviewer_018':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectId", project_id)
            self.call_api(data)
        if data['ID'] == 'Team_submitApply_019':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            client_name_sql = "select client_name from dms_project where id='" + project_id + "';"
            client_name = courser.exec_query(client_name_sql)[0][0]
            data['body'] = replace_params_item(data['body'], "projectName", project_name_with_code)
            data['body'] = replace_params_item(data['body'], "clientName", client_name)
            data['body'] = replace_params_item(data['body'], "projectId", project_id)
            self.call_api(data)
        if data['ID'] == 'Team_applySearch_020':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            self.call_api(data)
            request_no_sql = "select request_no from dms_project_button_right where project_id='" + project_id + "';"
            request_no = courser.exec_query(request_no_sql)[0][0]
            request_id_sql = "select id from dms_project_button_right where project_id='" + project_id + "';"
            request_id = courser.exec_query(request_id_sql)[0][0]
        if data['ID'] == 'OPL_login_021':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.opl[2])
            self.call_api(data)
        if data['ID'] == 'OPL_queryApply_022':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'OPL_login_021')
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            data['params'] = replace_params_item(data['params'], "requestNo", request_no)
            self.call_api(data)
        if data['ID'] == 'OPL_openApply_023':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "id", request_id)
            self.call_api(data)
        if data['ID'] == 'OPL_queryNextReviewer_024':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectId", project_id)
            data['params'] = replace_params_item(data['params'], "buttonRightId", request_id)
            self.call_api(data)
        if data['ID'] == 'OPL_approveApply_025':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_params_item(data['body'], "rightRequestId", request_id)
            data['body'] = replace_params_item(data['body'], "projectName", project_name_with_code)
            data['body'] = replace_params_item(data['body'], "clientName", client_name)
            data['body'] = replace_params_item(data['body'], "projectId", project_id)
            self.call_api(data)
        if data['ID'] == 'Reopen_login_026':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.reopen[2])
            self.call_api(data)
        if data['ID'] == 'Reopen_queryApply_027':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'Reopen_login_026')
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            data['params'] = replace_params_item(data['params'], "requestNo", request_no)
            self.call_api(data)
        if data['ID'] == 'Reopen_openApply_028':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "id", request_id)
            self.call_api(data)
        if data['ID'] == 'Reopen_queryNextReviewer_029':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectId", project_id)
            data['params'] = replace_params_item(data['params'], "buttonRightId", request_id)
            self.call_api(data)
        if data['ID'] == 'Reopen_approveApply_030':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_params_item(data['body'], "rightRequestId", request_id)
            data['body'] = replace_params_item(data['body'], "projectName", project_name_with_code)
            data['body'] = replace_params_item(data['body'], "clientName", client_name)
            data['body'] = replace_params_item(data['body'], "projectId", project_id)
            self.call_api(data)


if __name__ == '__main__':
    unittest.main()
