# _*_ coding:utf-8 _*_

import unittest
import requests
import ddt
from lib.read_excel import ReadExcel
from call_api import CallAPI
from lib.parse_file import generate_file_path

# 读取测试用例
case_file = generate_file_path(".DemoAPITestCase_Isolate.xlsx", flag='c')
testData = ReadExcel(case_file, "Sheet1").read_data()
# excel版测试报告，同时用于存储每个接口的返回结果
report_file = generate_file_path(".DemoAPITestCase_Isolate.xlsx", flag='r')


# 脚本均继承CallAPI类，复用call_api方法
@ddt.ddt
class IsolateDemoAPI(unittest.TestCase, CallAPI):
    """XXX系统"""
    def setUp(self):
        self.s = requests.session()

    def tearDown(self):
        pass

    # 数据驱动测试，excel中每一行视为一条测试用例传给方法的data参数
    @ddt.data(*testData)
    def test_isolate_api(self, data):
        """
        当所有接口均是独立的（无相互依赖），则只需在该方法体内直接调用call_api方法
        """

        self.call_api(data)


if __name__ == '__main__':
    unittest.main()
