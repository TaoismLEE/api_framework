from config.setting import JOB_TEST, JOB_TEST_ACCOUNT, JOB_TEST_PWD, JOB_UAT, JOB_UAT_ACCOUNT, JOB_UAT_PWD, \
    SURVEY_TEST_ID, SURVEY_UAT_ID, JOB_PRE, JOB_PRE_PWD, JOB_PRE_ACCOUNT, SURVEY_PRE_ID
from lib.send_requests import SendRequests
import requests, time
from lib.log import logger


def trigger_job(job_api_data, env):
    session = requests.session()
    if env == "test":
        test_login_api = {"method": "POST",
                          "url": JOB_TEST + "/tax-job/login",
                          "params": "",
                          "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                          "body": {"userName": JOB_TEST_ACCOUNT,
                                   "password": JOB_TEST_PWD},
                          "type": "data"}
        # 适配send_request函数，将参数值转换为String
        test_login_api['headers'] = str(test_login_api['headers'])
        test_login_api['body'] = str(test_login_api['body'])
        # 登陆系统获取cookie
        re = SendRequests().send_request(session, test_login_api)
        cookie = re.cookies['XXL_JOB_LOGIN_IDENTITY']
        # 触发执行创建问卷JOB
        job_api_data['headers']['Cookie'] = 'XXL_JOB_LOGIN_IDENTITY=' + cookie
        job_api_data['url'] = JOB_TEST + job_api_data['url']
        job_api_data['body']['id'] = int(SURVEY_TEST_ID)
        job_api_data['headers'] = str(job_api_data['headers'])
        job_api_data['body'] = str(job_api_data['body'])
        re = SendRequests().send_request(session, job_api_data)
        time.sleep(30)

    elif env == 'uat':
        uat_login_api = {"method": "POST",
                          "url": JOB_UAT + "/tax-job/login",
                          "params": "",
                          "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                          "body": {"userName": JOB_UAT_ACCOUNT,
                                   "password": JOB_UAT_PWD},
                          "type": "json"}
        # 适配send_request函数，将参数值转换为String
        uat_login_api['headers'] = str(uat_login_api['headers'])
        uat_login_api['body'] = str(uat_login_api['body'])
        # 登陆系统获取cookie
        re = SendRequests().send_request(session, uat_login_api)
        cookie = re.cookies['XXL_JOB_LOGIN_IDENTITY']
        # 触发执行创建问卷JOB
        job_api_data['headers']['Cookie'] = 'XXL_JOB_LOGIN_IDENTITY=' + cookie
        job_api_data['url'] = JOB_UAT + job_api_data['url']
        job_api_data['body']['id'] = int(SURVEY_UAT_ID)
        job_api_data['headers'] = str(job_api_data['headers'])
        job_api_data['body'] = str(job_api_data['body'])
        re = SendRequests().send_request(session, job_api_data)
        time.sleep(30)

    elif env == 'dc_pre_mlr':
        pre_login_api = {"method": "POST",
                          "url": JOB_PRE + "/edms-pre-job/login",
                          "params": "",
                          "headers": {"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                          "body": {"userName": JOB_PRE_ACCOUNT,
                                   "password": JOB_PRE_PWD},
                          "type": "data"}
        # 适配send_request函数，将参数值转换为String
        pre_login_api['headers'] = str(pre_login_api['headers'])
        pre_login_api['body'] = str(pre_login_api['body'])
        # 登陆系统获取cookie
        re = SendRequests().send_request(session, pre_login_api)
        cookie = re.cookies['XXL_JOB_LOGIN_IDENTITY']
        # 触发执行创建问卷JOB
        job_api_data['headers']['Cookie'] = 'XXL_JOB_LOGIN_IDENTITY=' + cookie
        job_api_data['url'] = JOB_PRE + job_api_data['url']
        job_api_data['body']['id'] = int(SURVEY_PRE_ID)
        job_api_data['headers'] = str(job_api_data['headers'])
        job_api_data['body'] = str(job_api_data['body'])
        re = SendRequests().send_request(session, job_api_data)
        time.sleep(30)
