from lib.read_excel import ReadExcel
from config.setting import JOB_TEST, JOB_TEST_ACCOUNT, JOB_TEST_PWD, JOB_UAT, JOB_UAT_ACCOUNT, JOB_UAT_PWD, DC_TEST, \
    DC_UAT, DC_PRE_MLR
import json


def parse_token(report_file, test_case_id):
    temp_data = ReadExcel(report_file, "Sheet1").read_data()
    pre_api_response = [item for item in temp_data if item['ID'] == test_case_id]
    access_token = "Bearer " + eval(pre_api_response[0]['response'])['access_token']
    return access_token


def load_api_response(report_file, test_case_id):
    temp_data = ReadExcel(report_file, "Sheet1").read_data()
    pre_api_response = [item for item in temp_data if item['ID'] == test_case_id]
    return eval(pre_api_response[0]['response'])


def parse_json(data, expect_dict={}):
    """
    :param data: json, http return content
    :param expect_dict: one key_value dict, expected key_value item
    :return: 0/1: if exists return 1, else return 0
    """
    flag = 0
    if isinstance(data, list):
        for item in data:
            if parse_json(item, expect_dict=expect_dict):
                return 1
    elif isinstance(data, dict):
        for key, value in data.items():
            if str(key) == str(list(expect_dict.keys())[0]) and str(value) == str(list(expect_dict.values())[0]):
                return 1
            else:
                if parse_json(value, expect_dict=expect_dict):
                    return 1

    return flag


def parse_json_value(report_file, test_case_id, value_path):
    temp_data = ReadExcel(report_file, "Sheet1").read_data()
    pre_api_response = [item for item in temp_data if item['ID'] == test_case_id]
    value = str(eval(pre_api_response[0]['response'])) + value_path
    return eval(value)


def rebuild_header(excel_header, access_token):
    headers = eval(excel_header)
    headers['Authorization'] = access_token
    return str(headers)


def rebuild_url(data, base_url):
    api = data['url']
    full_url = base_url + api
    return str(full_url)


def rebuild_login_body(data, account):
    body_dict = eval(data['body'])
    body_dict['username'] = account
    return str(body_dict)


def fetch_user_info(user_list, role):
    """
    :param user_list: list, with all info from account file
    :param role: str, role name
    :return: tuple(staff_no, user_enName, account)
    """
    for user in user_list:
        if user[0] == role:
            return user[3], user[5], user[1]


def replace_project_user(body, user, project_role):
    """
    :param body: str, request body
    :param user: tuple, (staff_no,en_name)
    :param project_role: str
    :return: str, new request body
    """
    data = json.loads(body)
    if project_role == 'staff':
        data['staff'] = user[0]
        data['staffName'] = user[1]
    elif project_role == 'mic':
        data['mic'] = user[0]
        data['micName'] = user[1]
    elif project_role == 'pic':
        data['pic'] = user[0]
        data['picName'] = user[1]
    elif project_role == 'cpic':
        data['conPartner'] = user[0]
        data['conPartnerName'] = user[1]
    elif project_role == 'specialRisk':
        data['riskReviewer'] = user[0]
        data['riskReviewerName'] = user[1]
    elif project_role == 'ppic':
        data['ppic'] = user[0]
        data['ppicName'] = user[1]
    elif project_role == 'codePic':
        data['codePic'] = user[0]
        data['codePicName'] = user[1]
    elif project_role == 'codeMic':
        data['codeMic'] = user[0]
        data['codeMicName'] = user[1]

    return json.dumps(data)


def replace_project_name(body, project_name):
    """
    :param body: str, request body
    :param project_name: str, name
    :return: str, new request body
    """
    data = json.loads(body)
    data['projectName'] = project_name

    return json.dumps(data)


def replace_client_name(body, client_name):
    """
    :param body: str, request body
    :param client_name: str, name
    :return: str, new request body
    """
    data = json.loads(body)
    data['clientName'] = client_name

    return json.dumps(data)


def replace_body_item(body, item_name, item_value):
    """
    :param body: str, request body
    :param item_name: str, name
    :param item_value: str, value
    :return: str, new request body
    """
    data = json.loads(body)
    data[item_name] = item_value

    return json.dumps(data)


def replace_body_list(body, item_name, list_value):
    """
    :param body: str, request body
    :param item_name: str, name
    :param list_value: list, value
    :return: str, new request body
    """
    data = json.loads(body)
    data[item_name] = list_value

    return json.dumps(data)


def replace_params_item(params, item_name, item_value):
    """
    :param params: str, request params
    :param item_name: str, name
    :param item_value: str, value
    :return: str, new request params
    """
    data = json.loads(params)
    data[item_name] = item_value

    return json.dumps(data)


def fetch_project_base_url(env):
    if env == 'test':
        return DC_TEST
    elif env == 'uat':
        return DC_UAT
    elif env == 'dc_pre_mlr':
        return DC_PRE_MLR


def fetch_job_base_url(env):
    if env == 'test':
        return JOB_TEST
    elif env == 'uat':
        return JOB_UAT


def fetch_db_config(cf, env):
    if env == 'test':
        host = cf.get("TEST", "host")
        port = cf.get("TEST", "port")
        user = cf.get("TEST", "user")
        pwd = cf.get("TEST", "password")
        db = cf.get("TEST", "db_efilling_name")
        return host, port, user, pwd, db
    elif env == 'uat':
        host = cf.get("UAT", "host")
        port = cf.get("UAT", "port")
        user = cf.get("UAT", "user")
        pwd = cf.get("UAT", "password")
        db = cf.get("UAT", "db_efilling_name")
        return host, port, user, pwd, db
    elif env == 'dc_pre_mlr':
        host = cf.get("PRE-DC", "host_pre_dc")
        port = cf.get("PRE-DC", "port_pre_dc")
        user = cf.get("PRE-DC", "user_pre_dc")
        pwd = cf.get("PRE-DC", "password_pre_dc")
        db = cf.get("PRE-DC", "db_efilling_name_pre_dc")
        return host, port, user, pwd, db
