import time, datetime


class FormatTime:
    def __init__(self, v_time=time.time(), shift_minute=0):
        self.origin_time = v_time
        self.shift_minute = shift_minute

    def formater_1(self):
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.origin_time))

    def formater_2(self):
        return time.strftime('%Y%m%d%H%M%S', time.localtime(self.origin_time))

    def formater_3(self):
        # 精确到毫秒
        time_stamp = "%s.%03d" % (self.formater_1(), (self.origin_time - int(self.origin_time))*1000)
        stamp = "".join((time_stamp.split()[0]).split("-")) + "".join(time_stamp.split()[1].split(":")).replace('.', '')
        return stamp

    def formater_4(self):
        current_time = datetime.datetime.now()
        new_time = current_time - datetime.timedelta(minutes=self.shift_minute)
        return new_time.strftime('%Y%m%d%H%M%S')
