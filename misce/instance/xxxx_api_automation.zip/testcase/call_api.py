# _*_ coding:utf-8 _*_
import unittest
from lib.send_requests import SendRequests
from lib.write_excel import WriteExcel
from lib.project_functions import parse_json


class CallAPI:
    """

    """
    def call_api(self, data, files="", type_flag=1, result_check={}):
        # 获取ID字段数值，截取结尾数字并去掉开头0，用以判断用例所在行
        rowNum = int(data['ID'].split("_")[2])
        print("******* 正在执行用例 ->{0} *********".format(data['ID']))
        print("请求方式: {0}".format(data['method']))
        print("请求URL: {0}".format(data['url']))
        print("请求头: {0}".format(data['headers']))
        print("请求参数: {0}".format(data['params']))
        print("post请求body类型为：{0} ,body内容为：{1}".format(data['type'], data['body']))

        # 发送请求, flag默认为1表示普通请求，当是请求上传文件时，显式传flag=0
        if type_flag:
            re = SendRequests().send_request(self.s, data)
        else:
            re = SendRequests().send_upload_file_request(self.s, data, files)

        # 获取服务端返回
        self.result = re.json()
        print("页面返回信息：%s" % re.content.decode("utf-8"))

        # 获取excel表格接口的状态码和Message
        try:
            int(self.result["code"])
        except KeyError:
            print("API does NOT have status property, currently we think of it success if len(response) > 0!")
            if len(self.result) > 0:
                check_result = "PASS"
                print("用例测试结果:  {0}---->{1}".format(data['ID'], check_result))
                WriteExcel(self.report_file, self.case_file).write_data(rowNum + 1, check_result, self.result)
        else:
            expect_code = int(data['status_code'])
            expect_msg = data["msg"]
            if expect_msg:
                if expect_code == self.result['code'] and expect_msg == self.result['msg']:
                    value_check_flag = 1
                    if len(result_check):
                        for key in result_check.keys():
                            if not parse_json(self.result, {key: result_check[key]}):
                                # 检查项中有任意一项不在接口返回中，则检查失败，退出循环
                                value_check_flag = 0
                                break
                    if value_check_flag:
                        check_result = "PASS"
                    else:
                        check_result = "FAIL"
                    print("用例测试结果:  {0}---->{1}".format(data['ID'], check_result))
                    WriteExcel(self.report_file, self.case_file).write_data(rowNum + 1, check_result, self.result)
                    self.assertEqual(value_check_flag, 1, "期望数据检查结果是: %s" % check_result)
                if expect_code != self.result['code'] or expect_msg != self.result['msg']:
                    check_result = "FAIL"
                    print("用例测试结果:  {0}---->{1}", format(data['ID'], check_result))
                    WriteExcel(self.report_file, self.case_file).write_data(rowNum + 1, check_result, self.result)
                self.assertEqual(self.result['code'], expect_code, "返回实际结果是->: %s" % self.result['code'])
                self.assertEqual(self.result['msg'], expect_msg, "返回实际结果是->: %s" % self.result['msg'])
            else:
                if expect_code == self.result['code']:
                    value_check_flag = 1
                    if len(result_check):
                        for key in result_check.keys():
                            if not parse_json(self.result, {key: result_check[key]}):
                                # 检查项中有任意一项不在接口返回中，则检查失败，退出循环
                                value_check_flag = 0
                                break
                    if value_check_flag:
                        check_result = "PASS"
                    else:
                        check_result = "FAIL"
                    print("用例测试结果:  {0}---->{1}".format(data['ID'], check_result))
                    WriteExcel(self.report_file, self.case_file).write_data(rowNum + 1, check_result, self.result)
                    self.assertEqual(value_check_flag, 1, "期望数据检查结果是: %s" % check_result)
                if expect_code != self.result['code']:
                    check_result = "FAIL"
                    print("用例测试结果:  {0}---->{1}".format(data['ID'], check_result))
                    WriteExcel(self.report_file, self.case_file).write_data(rowNum + 1, check_result, self.result)
                self.assertEqual(self.result['code'], expect_code, "返回实际结果是->: %s" % self.result['code'])


if __name__ == '__main__':
    unittest.main()
