# _*_ coding:utf-8 _*_

import os
import sys
PROJECT_PATH = os.path.dirname(os.path.dirname(__file__))
sys.path.append(PROJECT_PATH)

# 当前运行环境
# ENV = 'test'
# ENV = 'uat'
ENV = 'dc_pre_mlr'

# 配置文件
TEST_CONFIG = os.path.join(PROJECT_PATH, "config", "db.ini")
# 测试用例程序文件
TEST_CASE = os.path.join(PROJECT_PATH, "testcase")
# 测试用例报告
TEST_REPORT = os.path.join(PROJECT_PATH, "report")


# outlook邮箱配置
MAIL_HOST = "shintsmtp.deloitte.com.cn"
MAIL_PORT = 25
MAIL_USER = ""
MAIL_PWD = ""
MAIL_SENDER = "yuliy@deloitte.com.cn"

# 邮件接受者
# MAIL_RECEIVERS = ["yuliy@deloitte.com.cn"]
# MAIL_RECEIVERS = ["yuliy@deloitte.com.cn",
#                   "cinochen@deloitte.com.cn"]
MAIL_RECEIVERS = ["yuliy@deloitte.com.cn",
                  "cinochen@deloitte.com.cn",
                  "kanliu@deloitte.com.cn",
                  "scgong@deloitte.com.cn"
                  ]

# 邮件主题
MAIL_SUBJECT = "eDMS-PRE-SOE(DC) - 接口自动化测试结果"

# 环境地址
DC_TEST = "http://10.172.64.205:10010"
DC_UAT = "https://drtax.deloitte.com.cn/uat_edms"
DC_PRE_MLR = "http://10.172.64.201:10000/DC/ML-Restricted"

# 任务调度中心
JOB_TEST = "http://10.172.64.204:8792"
JOB_UAT = "http://10.172.64.204:8792"
JOB_PRE = "http://10.172.128.201:11000"

# 任务调度中心账号信息
JOB_TEST_ACCOUNT = "admin"
JOB_TEST_PWD = "123456"

JOB_UAT_ACCOUNT = "admin"
JOB_UAT_PWD = "123456"

JOB_PRE_ACCOUNT = "admin"
JOB_PRE_PWD = "321qaz"

# 定时任务ID
SURVEY_TEST_ID = 236
SURVEY_UAT_ID = 157
SURVEY_PRE_ID = 63



