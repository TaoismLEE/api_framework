# _*_ coding:utf-8 _*_

import unittest, requests, ddt, uuid, re
from config.setting import ENV, PROJECT_PATH
from lib.read_excel import ReadExcel
from call_api import CallAPI
from lib.parse_file import generate_file_path
from lib.project_functions import rebuild_header, fetch_user_info, parse_token, replace_body_item,\
    replace_project_user, replace_project_name, replace_client_name, replace_params_item, rebuild_url, \
    fetch_project_base_url, rebuild_login_body, fetch_db_config, parse_json_value, replace_body_list
from lib.parse_file import ParseCSV
from lib.log import logger
from lib.timer import FormatTime
from lib.mssql_db import MSSQL
import configparser as cparser
from config import setting

# --------- 读取config.ini配置文件 ---------------
cf = cparser.ConfigParser()
cf.read(setting.TEST_CONFIG, encoding='UTF-8')
host, port, user, pwd, db = fetch_db_config(cf, ENV)

case_file = generate_file_path("dc_KMTracking_API_TestCase.xlsx", flag='c')
report_file = generate_file_path("dc_KMTracking_API_TestCase.xlsx", flag='r')
testData = ReadExcel(case_file, "Sheet1").read_data()

DC_BASE_URL = fetch_project_base_url(ENV)
upload_file = '1M.txt'
access_token = ""
project_name_with_code = ""
project_id = ""
km_action_business_id = ""
action_item_file_id = ""
comment_file_id = ""


@ddt.ddt
class KMTrackingDCAPI(unittest.TestCase, CallAPI):
    """EDMS_DC_测试用户创建项目后，KM添加Action及Comment，然后用户查看并反馈，最后KM确认的完整流程"""
    def setUp(self):
        self.s = requests.session()
        # 获取用户信息
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.account = accounts[2][1]
            self.password = accounts[2][2]
            self.staff_no = accounts[2][3]
            self.en_name = accounts[2][5]
            self.km_account = accounts[9][1]
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        # 获取用例与excel报告文件地址
        self.case_file = case_file
        self.report_file = report_file

    def tearDown(self):
        pass

    @ddt.data(*testData)
    def test_KM_Tracking_apis(self, data):
        """
        测试用户创建项目，然后KM添加action及comment全流程
        """
        global access_token, project_name_with_code, project_id, km_action_business_id
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.staff = fetch_user_info(accounts, 'staff')
            self.mic = fetch_user_info(accounts, 'mic')
            self.pic = fetch_user_info(accounts, 'pic')
            self.cpic = fetch_user_info(accounts, 'cpic')
            self.special_risk = fetch_user_info(accounts, 'specialRisk')
            self.ppic = fetch_user_info(accounts, 'ppic')
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        if data['ID'] == 'login_trigger_001':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.account)
            self.call_api(data)
        if data['ID'] == 'project_createWithEngCode_002':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_trigger_001')
            data['headers'] = rebuild_header(data['headers'], access_token)
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            # 向dms_sync_project表插入一条项目数据用于创建有CODE项目
            current_time = str(FormatTime(shift_minute=20).formater_4())
            sync_code_sql = "INSERT INTO [dms_sync_project]([id], [creation_date], [created_by], [created_by_en_name], [created_by_name], [del_flag], [deleted_by], [deletion_date], [last_updated_by], [last_updated_by_enname], [last_updated_by_name], [last_update_date], [status], [tenant_id], [record_version], [affiliate_of_listed_entity], [affiliate_of_sec_restricted_entity], [biz_registration_no], [cea_approval_date], [cea_ecc_case_no], [cea_no], [cea_preparer], [cea_status], [chinese_name1], [chinese_name2], [client_code], [client_name], [client_risk], [close_date], [engagement_code], [company_code], [con_curring_partner_reason], [con_partner_advise_engagement], [confidentiality_risk], [contract_c], [dtt_relation_ship], [eng_code], [eng_desc], [eng_letter_no], [engagement_desc], [engagement_risk], [eqar_partner], [est_fee], [existing_audit_client], [fisy], [func_code], [industry_code], [industry_desc], [is_contingent_basis], [is_master_eng], [is_recurring], [lcsp], [lcsp_name], [legal_name], [location_code], [master_eng_code], [mic], [mic_name], [nature_of_business], [opportunity_id], [opportunity_name], [opportunity_source], [pic], [pic_name], [plan_recover_rate], [primary_addr], [primary_city], [primary_country], [primary_province], [profit_center], [rc_code], [region_code], [scope_of_services], [sec_registrant], [sec_restricted_entity], [segment_code], [service_code], [service_item_team_member], [service_offer_desc], [start_date], [stock_code], [stock_exchange], [type_of_client], [year_end_month], [master_company_cn], [master_code], [master_company], [ppic1], [ppic1_name], [ppic2], [ppic2name], [level1_code], [level2_code], [create_date], [segment_desc], [service_item_team_member_name], [cea_preparer_name], [eqar_partner_name], [ppic2_name], [ppic], [ppic_name], [alliance_partner], [alliance_partner_desc]) VALUES ('" + str(
                uuid.uuid1()) + "','2022-02-15 13:49:44.7280000', 'System', NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, '2022-02-15 13:49:44.7280000', NULL, 'DC', 1, 'No', 'Yes', '8080-01', '2020-01-05 09:44:00.0000000', 'CEA-SH-DC-456933', N'CEA-SH-DC-456933', '', 'Approved', N'Massive Data', N'HuaLongWang-MassiveData', N'8080', N'HuaLongWang-MassiveData HLW CO. LTD', 'High', NULL, N'" + current_time + "-02-DC',  N'SH3A', N'AutoTest for DC', 'No', 'Normal', N'USD', N'DTT_RelationShip', N'" + current_time + "-02-DC', N'AutoTest-20220215-134724', 'EL19SHF456933', N'AutoTest-20220215-134724', 'Much Great', '1004', 50000.00, 'Yes', 2021, N'CON', N'CTS2', N'Consumer/TH&S/Services', 'Yes', N'Y', N'N', N'1009', 'edmspicSM', N'CQ Press', N'SH', N'', N'1002', 'edmspicMic', N'Consumer/TH&S/Services', '456933', N'project-456933', N'Existing Client', N'1003', 'edmspicPic', 40.000000000000000, N'CQ Danzishi Energy Tower       ', N'China', N'Chongqing', N'Chongqing', N'16F140', '1FC1003069', N'EC', N'scope of service 456933', N'456933 & Co. Inc.', 'No', N'SOEZZZ0', N'OJC', N'1001', N'SAM JP-CN Collaboration', '2021-06-05 00:00:00.0000000', N'Stock_Code_Exchange;', N'', 'Corporation', N'10', N'德勤咨询（上海）有限公司', 'SH3A', 'Deloitte & ToucheFinancial Advisory Services Limited', N'10014', 'edmsmicPpic', N'', NULL, N'CZZ0', N'CTZ0', '2021-04-30 00:00:00.000', N'CENTRAL SOE', N'edmspicStaff', N'', N'edmspicCpic', N'', N'10014', N'edmsmicPpic', NULL, NULL);"
            courser.exec_non_query(sync_code_sql)
            # 查询项目CODE属性，用于填充创建项目接口参数
            eng_code_sql = "select top 1 master_company, company_code, engagement_code, client_code, client_name, cea_no, eng_letter_no, region_code, location_code, rc_code, master_company_cn from dms_sync_project where engagement_code like '" + current_time + "%' and engagement_code not in (select code from dms_project where code like '" + current_time + "%');"
            eng_code = courser.exec_query(eng_code_sql)[0]
            # 替换模板数据中项目人员数据
            data['body'] = replace_project_user(data['body'], self.staff, 'staff')
            data['body'] = replace_project_user(data['body'], self.mic, 'mic')
            data['body'] = replace_project_user(data['body'], self.pic, 'pic')
            data['body'] = replace_project_user(data['body'], self.cpic, 'cpic')
            data['body'] = replace_project_user(data['body'], self.special_risk, 'specialRisk')
            # 替换模板数据中CODE人员数据
            data['body'] = replace_project_user(data['body'], self.ppic, 'ppic')
            data['body'] = replace_project_user(data['body'], self.mic, 'codeMic')
            data['body'] = replace_project_user(data['body'], self.pic, 'codePic')
            # 修改模板数据中的非账号数据
            data['body'] = replace_body_item(data['body'], 'masterCompany', eng_code[0])
            data['body'] = replace_body_item(data['body'], 'masterCompanyCode', eng_code[1])
            data['body'] = replace_body_item(data['body'], 'code', eng_code[2])
            project_name_with_code = "DC_AutoTest_" + str(eng_code[2])
            data['body'] = replace_project_name(data['body'], project_name_with_code)
            data['body'] = replace_body_item(data['body'], 'clientCode', eng_code[3])
            data['body'] = replace_client_name(data['body'], eng_code[4])
            data['body'] = replace_body_item(data['body'], 'ceaNo', eng_code[5])
            data['body'] = replace_body_item(data['body'], 'engLetterNo', eng_code[6])
            data['body'] = replace_body_item(data['body'], 'regionCode', eng_code[7])
            data['body'] = replace_body_item(data['body'], 'locationCode', eng_code[8])
            data['body'] = replace_body_item(data['body'], 'rcCode', eng_code[9])
            data['body'] = replace_body_item(data['body'], 'masterCompanyCN', eng_code[10])
            data['body'] = replace_body_item(data['body'], 'engagementDesc', project_name_with_code + '_Desc')
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'project_queryProjectCode_003':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            project_sql = "SELECT id from dms_project where project_name='" + project_name_with_code + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            project_id = courser.exec_query(project_sql)[0][0]
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'login_km_004':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.km_account)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'km_queryProject_005':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_km_004')
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'km_uploadActionFile_006':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # generate headers
            data['headers'] = re.sub(r"'x-token': 'f5a9767a-0203-4e31-ad53-0bc4709ebf0f'", "'x-token': '" +
                                     access_token.split()[1] + "'", str(data['headers']))
            # generate body
            file_path = PROJECT_PATH + u'/data/' + upload_file
            file = {
                "file": (upload_file, open(file_path, 'rb')),
            }
            data['body'] = replace_body_item(data['body'], 'businessId', project_id)
            # 调用API请求函数
            self.call_api(data, files=file, type_flag=0)
        if data['ID'] == 'km_uploadCommentFile_007':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # generate headers
            data['headers'] = re.sub(r"'x-token': 'f5a9767a-0203-4e31-ad53-0bc4709ebf0f'", "'x-token': '" +
                                     access_token.split()[1] + "'", str(data['headers']))
            # generate body
            file_path = PROJECT_PATH + u'/data/' + upload_file
            file = {
                "file": (upload_file, open(file_path, 'rb')),
            }
            data['body'] = replace_body_item(data['body'], 'businessId', project_id)
            # 调用API请求函数
            self.call_api(data, files=file, type_flag=0)
        if data['ID'] == 'km_addActionItem_008':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], "projectId", project_id)
            action_item_file_id = parse_json_value(report_file, 'km_uploadActionFile_006', '["data"]["logicFileId"]')
            upload_files = []
            upload_files.append(action_item_file_id)
            data['body'] = replace_body_list(data['body'], "attachmentIds", upload_files)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'km_addComment_009':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], "projectId", project_id)
            comment_file_id = parse_json_value(report_file, 'km_uploadCommentFile_007', '["data"]["logicFileId"]')
            upload_files = []
            upload_files.append(comment_file_id)
            data['body'] = replace_body_list(data['body'], "attachmentIds", upload_files)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'km_queryActionItem_010':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectId", project_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'km_queryComment_011':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectId", project_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'login_trigger_012':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.account)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'Team_commentQuery_013':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_trigger_012')
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            data['params'] = replace_params_item(data['params'], "staffNo", self.staff_no)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'Team_actionItemQuery_014':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "projectName", project_name_with_code)
            data['params'] = replace_params_item(data['params'], "staffNo", self.staff_no)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'Team_actionItemDetail_015':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            km_action_business_id_sql = "SELECT id from dms_km_action where project_id='" + project_id + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            km_action_business_id = courser.exec_query(km_action_business_id_sql)[0][0]
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "businessId", km_action_business_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'Team_actionItemFeedback_016':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], "businessId", km_action_business_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'Team_feedbackActionItem_017':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], "projectId", project_id)
            data['body'] = replace_body_item(data['body'], "id", km_action_business_id)
            data['body'] = replace_body_item(data['body'], "feedbackRemark", project_name_with_code)
            # 调用API请求函数
            self.call_api(data)


if __name__ == '__main__':
    unittest.main()
