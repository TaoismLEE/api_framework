# _*_ coding:utf-8 _*_

import unittest, requests, ddt, re, json, uuid
from lib.read_excel import ReadExcel
from config.setting import ENV, PROJECT_PATH
from call_api import CallAPI
from lib.parse_file import generate_file_path
from lib.project_functions import rebuild_header, fetch_user_info, parse_token,\
    replace_project_user, replace_project_name, replace_client_name, replace_body_item, rebuild_url,\
    rebuild_login_body, fetch_project_base_url, fetch_db_config, replace_params_item, load_api_response
from lib.parse_file import ParseCSV
from lib.log import logger
from lib.timer import FormatTime
from lib.mssql_db import MSSQL
from lib.trigger_job import trigger_job
import configparser as cparser
from config import setting

# --------- 读取config.ini配置文件 ---------------
cf = cparser.ConfigParser()
cf.read(setting.TEST_CONFIG, encoding='UTF-8')
host, port, user, pwd, db = fetch_db_config(cf, ENV)
# toolkit申请JSON字符数太长，单独维护在下面文件中
apply_file = 'DC_toolkit_apply_template.txt'


case_file = generate_file_path("dc_fileBorrow_Team_Apply_and_KM_Approve_API_TestCase.xlsx", flag='c')
report_file = generate_file_path("dc_fileBorrow_Team_Apply_and_KM_Approve_API_TestCase.xlsx", flag='r')
cata_maint_report_file = generate_file_path("dc_fileBorrow_KM_Maint_and_Team_Query_API_TestCase.xlsx", flag='r')
testData = ReadExcel(case_file, "Sheet1").read_data()

access_token = ""
project_name_with_code = ""
DC_BASE_URL = fetch_project_base_url(ENV)
project_id = ""
catalogApplyId = ""
courser = ""
apply_id = ""
borrow_from_project_id = ""
borrow_from_project_name = ""


@ddt.ddt
class ApplyAndKMFeedbackAPI(unittest.TestCase, CallAPI):
    """EDMS_DC_测试用户创建项目资料申请，然后KM人员反馈全流程"""
    def setUp(self):
        self.s = requests.session()
        # 获取用户信息
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.account = accounts[2][1]
            self.password = accounts[2][2]
            self.staff_no = accounts[2][3]
            self.en_name = accounts[2][5]
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        # 获取用例与excel报告文件地址
        self.case_file = case_file
        self.report_file = report_file

    def tearDown(self):
        pass

    @ddt.data(*testData)
    def test_apply_and_KM_feedback_apis(self, data):
        """
        测试用户创建项目并提交toolkit申请，然后审核全流程
        """
        global access_token, project_name_with_code, project_id, courser, apply_id, catalogApplyId, \
            borrow_from_project_id, borrow_from_project_name
        try:
            csv_obj = ParseCSV('edms_dc_accounts.csv')
            accounts = csv_obj.read_csv()
            self.staff = fetch_user_info(accounts, 'staff')
            self.mic = fetch_user_info(accounts, 'mic')
            self.pic = fetch_user_info(accounts, 'pic')
            self.cpic = fetch_user_info(accounts, 'cpic')
            self.special_risk = fetch_user_info(accounts, 'specialRisk')
            self.ppic = fetch_user_info(accounts, 'ppic')
            self.kit_review = fetch_user_info(accounts, 'kitReview')
            self.cata_review = fetch_user_info(accounts, 'cataMgt')
        except Exception as e:
            logger.error("Failed to open data file!")
            logger.error(e)

        if data['ID'] == 'login_trigger_001':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.account)
            self.call_api(data)
        if data['ID'] == 'project_createWithEngCode_002':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_trigger_001')
            data['headers'] = rebuild_header(data['headers'], access_token)
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            # 向dms_sync_project表插入一条项目数据用于创建有CODE项目
            current_time = str(FormatTime(shift_minute=35).formater_4())
            sync_code_sql = "INSERT INTO [dms_sync_project]([id], [creation_date], [created_by], [created_by_en_name], [created_by_name], [del_flag], [deleted_by], [deletion_date], [last_updated_by], [last_updated_by_enname], [last_updated_by_name], [last_update_date], [status], [tenant_id], [record_version], [affiliate_of_listed_entity], [affiliate_of_sec_restricted_entity], [biz_registration_no], [cea_approval_date], [cea_ecc_case_no], [cea_no], [cea_preparer], [cea_status], [chinese_name1], [chinese_name2], [client_code], [client_name], [client_risk], [close_date], [engagement_code], [company_code], [con_curring_partner_reason], [con_partner_advise_engagement], [confidentiality_risk], [contract_c], [dtt_relation_ship], [eng_code], [eng_desc], [eng_letter_no], [engagement_desc], [engagement_risk], [eqar_partner], [est_fee], [existing_audit_client], [fisy], [func_code], [industry_code], [industry_desc], [is_contingent_basis], [is_master_eng], [is_recurring], [lcsp], [lcsp_name], [legal_name], [location_code], [master_eng_code], [mic], [mic_name], [nature_of_business], [opportunity_id], [opportunity_name], [opportunity_source], [pic], [pic_name], [plan_recover_rate], [primary_addr], [primary_city], [primary_country], [primary_province], [profit_center], [rc_code], [region_code], [scope_of_services], [sec_registrant], [sec_restricted_entity], [segment_code], [service_code], [service_item_team_member], [service_offer_desc], [start_date], [stock_code], [stock_exchange], [type_of_client], [year_end_month], [master_company_cn], [master_code], [master_company], [ppic1], [ppic1_name], [ppic2], [ppic2name], [level1_code], [level2_code], [create_date], [segment_desc], [service_item_team_member_name], [cea_preparer_name], [eqar_partner_name], [ppic2_name], [ppic], [ppic_name], [alliance_partner], [alliance_partner_desc]) VALUES ('" + str(
                uuid.uuid1()) + "','2022-02-15 13:49:44.7280000', 'System', NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, '2022-02-15 13:49:44.7280000', NULL, 'DC', 1, 'No', 'Yes', '8080-01', '2020-01-05 09:44:00.0000000', 'CEA-SH-DC-456933', N'CEA-SH-DC-456933', '', 'Approved', N'Massive Data', N'HuaLongWang-MassiveData', N'8080', N'HuaLongWang-MassiveData HLW CO. LTD', 'High', NULL, N'" + current_time + "-02-DC',  N'SH3A', N'AutoTest for DC', 'No', 'Normal', N'USD', N'DTT_RelationShip', N'" + current_time + "-02-DC', N'AutoTest-20220215-134724', 'EL19SHF456933', N'AutoTest-20220215-134724', 'Much Great', '1004', 50000.00, 'Yes', 2021, N'CON', N'CTS2', N'Consumer/TH&S/Services', 'Yes', N'Y', N'N', N'1009', 'edmspicSM', N'CQ Press', N'SH', N'', N'1002', 'edmspicMic', N'Consumer/TH&S/Services', '456933', N'project-456933', N'Existing Client', N'1003', 'edmspicPic', 40.000000000000000, N'CQ Danzishi Energy Tower       ', N'China', N'Chongqing', N'Chongqing', N'16F140', '1FC1003069', N'EC', N'scope of service 456933', N'456933 & Co. Inc.', 'No', N'SOEZZZ0', N'OJC', N'1001', N'SAM JP-CN Collaboration', '2021-06-05 00:00:00.0000000', N'Stock_Code_Exchange;', N'', 'Corporation', N'10', N'德勤咨询（上海）有限公司', 'SH3A', 'Deloitte & ToucheFinancial Advisory Services Limited', N'10014', 'edmsmicPpic', N'', NULL, N'CZZ0', N'CTZ0', '2021-04-30 00:00:00.000', N'CENTRAL SOE', N'edmspicStaff', N'', N'edmspicCpic', N'', N'10014', N'edmsmicPpic', NULL, NULL);"
            courser.exec_non_query(sync_code_sql)
            # 查询项目CODE属性，用于填充创建项目接口参数
            eng_code_sql = "select top 1 master_company, company_code, engagement_code, client_code, client_name, cea_no, eng_letter_no, region_code, location_code, rc_code, master_company_cn from dms_sync_project where engagement_code like '" + current_time +"%' and engagement_code not in (select code from dms_project where code like '" + current_time +"%');"
            eng_code = courser.exec_query(eng_code_sql)[0]
            # 替换模板数据中项目人员数据
            data['body'] = replace_project_user(data['body'], self.staff, 'staff')
            data['body'] = replace_project_user(data['body'], self.mic, 'mic')
            data['body'] = replace_project_user(data['body'], self.pic, 'pic')
            data['body'] = replace_project_user(data['body'], self.cpic, 'cpic')
            data['body'] = replace_project_user(data['body'], self.special_risk, 'specialRisk')
            # 替换模板数据中CODE人员数据
            data['body'] = replace_project_user(data['body'], self.ppic, 'ppic')
            data['body'] = replace_project_user(data['body'], self.mic, 'codeMic')
            data['body'] = replace_project_user(data['body'], self.pic, 'codePic')
            # 修改模板数据中的非账号数据
            data['body'] = replace_body_item(data['body'], 'masterCompany', eng_code[0])
            data['body'] = replace_body_item(data['body'], 'masterCompanyCode', eng_code[1])
            data['body'] = replace_body_item(data['body'], 'code', eng_code[2])
            project_name_with_code = "DC_AutoTest_" + str(eng_code[2])
            data['body'] = replace_project_name(data['body'], project_name_with_code)
            data['body'] = replace_body_item(data['body'], 'clientCode', eng_code[3])
            data['body'] = replace_client_name(data['body'], eng_code[4])
            data['body'] = replace_body_item(data['body'], 'ceaNo', eng_code[5])
            data['body'] = replace_body_item(data['body'], 'engLetterNo', eng_code[6])
            data['body'] = replace_body_item(data['body'], 'regionCode', eng_code[7])
            data['body'] = replace_body_item(data['body'], 'locationCode', eng_code[8])
            data['body'] = replace_body_item(data['body'], 'rcCode', eng_code[9])
            data['body'] = replace_body_item(data['body'], 'masterCompanyCN', eng_code[10])
            data['body'] = replace_body_item(data['body'], 'engagementDesc', project_name_with_code + '_Desc')
            # 调用API请求函数
            self.call_api(data)
            # 调三方系统（任务调度中心）生成问卷
            survey = {"method": "POST",
                          "url": "/edms-pre-job/jobinfo/trigger",
                          "params": "",
                          "headers": {},
                          "body": {"id": "",
                                   "executorParam": "DC"},
                          "type": "data"}
            trigger_job(survey, ENV)
        if data['ID'] == 'project_queryProjectCode_003':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            project_sql = "SELECT id from dms_project where project_name='" + project_name_with_code + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            project_id = courser.exec_query(project_sql)[0][0]
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'team_findProject_004':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], 'projectName', project_name_with_code)
            # 调用API请求函数
            self.call_api(data, result_check={"projectName": project_name_with_code})
        if data['ID'] == 'team_findNextReiviewer_005':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'team_submitApply_006':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], 'projectId', project_id)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'team_findApply_007':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            apply_id_sql = "select id from dms_catalog_apply where project_id='" + project_id + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            apply_id = courser.exec_query(apply_id_sql)[0][0]
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_params_item(data['params'], 'projectName', project_name_with_code)
            # 调用API请求函数
            self.call_api(data, result_check={"projectName": project_name_with_code})
        if data['ID'] == 'login_trigger_008':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['body'] = rebuild_login_body(data, self.cata_review[2])
            self.call_api(data)
        if data['ID'] == 'cata_findApply_009':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            access_token = parse_token(report_file, 'login_trigger_008')
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_body_item(data['params'], 'projectName', project_name_with_code)
            # 调用API请求函数
            self.call_api(data, result_check={"projectName": project_name_with_code})
        if data['ID'] == 'cata_openDetail_010':
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            cata_apply_id_sql = "SELECT id from dms_catalog_apply where project_id='" + project_id + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            cata_apply_id = courser.exec_query(cata_apply_id_sql)[0][0]
            data['params'] = replace_body_item(data['params'], 'catalogApplyId', cata_apply_id)
            self.call_api(data, result_check={"projectName": project_name_with_code})
        if data['ID'] == 'cata_findProject_011':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            # 依赖于dc_fileBorrow_KM_Maint_and_Team_Query_API脚本执行结果：从结果中获取已维护分享数据的项目
            api_response = load_api_response(cata_maint_report_file, 'cata_projectSearch_007')
            borrow_from_project_id = api_response['data']['result'][0]['projectId']
            borrow_from_project_name = api_response['data']['result'][0]['projectName']
            data['params'] = replace_body_item(data['params'], 'projectName', borrow_from_project_name)
            # 调用API请求函数
            self.call_api(data, result_check={"projectName": borrow_from_project_name})
        if data['ID'] == 'cata_selectProject_012':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_body_item(data['params'], 'projectIds', borrow_from_project_id)
            # 调用API请求函数
            self.call_api(data, result_check={"projectName": borrow_from_project_name})
        if data['ID'] == 'cata_feedbackApply_013':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['body'] = replace_body_item(data['body'], 'id', apply_id)
            # 分别获取三类文件的ID，用于传参
            qualification_sql = "select id from dms_catalog_file_item where audit_file=0 and file_type='Qualification' and  project_id='" + borrow_from_project_id + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            qualification_file_id = courser.exec_query(qualification_sql)[0][0]
            proposal_sql = "select id from dms_catalog_file_item where audit_file=0 and file_type='Proposal' and  project_id='" + borrow_from_project_id + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            proposal_file_id = courser.exec_query(proposal_sql)[0][0]
            deliverable_sql = "select id from dms_catalog_file_item where audit_file=0 and file_type='Deliverable' and  project_id='" + borrow_from_project_id + "';"
            courser = MSSQL(host=host, user=user, pwd=pwd, db=db)
            deliverable_file_id = courser.exec_query(deliverable_sql)[0][0]
            body_dict = json.loads(data['body'])
            body_dict['list'][0]['itemId'] = qualification_file_id
            body_dict['list'][1]['itemId'] = proposal_file_id
            body_dict['list'][2]['itemId'] = deliverable_file_id
            data['body'] = json.dumps(body_dict)
            # 调用API请求函数
            self.call_api(data)
        if data['ID'] == 'cata_findApprovedApply_014':
            """
            通过从之前接口返回结果或是数据库查询数据进行data参数重构
            """
            data['url'] = rebuild_url(data, DC_BASE_URL)
            data['headers'] = rebuild_header(data['headers'], access_token)
            data['params'] = replace_body_item(data['params'], 'projectName', project_name_with_code)
            # 调用API请求函数
            self.call_api(data, result_check={"projectName": project_name_with_code})


if __name__ == '__main__':
    unittest.main()
